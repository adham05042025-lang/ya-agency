import React from 'react';

// Syne 800 outlines for "YA!" extracted from the bundled font (ya-mark generation).
// viewBox y is flipped via the group transform; baseline at y=0.
export function YaMark({ labelled = true }: { labelled?: boolean }) {
    return <svg className="ya-mark-svg" viewBox="0 -770 2624 850"
        role={labelled ? 'img' : undefined} aria-label={labelled ? 'YA! Creative Studio' : undefined} aria-hidden={labelled ? undefined : true}>
        <g transform="scale(1,-1)">
        <path className="ya-p-y" pathLength={100} transform="translate(0 0)" d="M1065 640 660 163V0H410V163L5 640H300L629 225H444L770 640Z" />
        <path className="ya-p-a" pathLength={100} transform="translate(1070 0)" d="M234 97V247H918V97ZM10 0 439 640H717L1150 0H875L504 573H653L285 0Z" />
        <path className="ya-p-bang" pathLength={100} transform="translate(2230 0)" d="M72 690H322V204H72ZM324 151V0H70V151Z" />
        <g className="ya-sheen-layer">
        <path transform="translate(0 0)" d="M1065 640 660 163V0H410V163L5 640H300L629 225H444L770 640Z" />
        <path transform="translate(1070 0)" d="M234 97V247H918V97ZM10 0 439 640H717L1150 0H875L504 573H653L285 0Z" />
        <path transform="translate(2230 0)" d="M72 690H322V204H72ZM324 151V0H70V151Z" />
        </g>
        </g>
        <defs>
        <linearGradient id="ya-sheen" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="700" y2="0">
            <stop offset="0" stopColor="#fff" stopOpacity="0" />
            <stop offset="0.5" stopColor="#fff" stopOpacity="0.55" />
            <stop offset="1" stopColor="#fff" stopOpacity="0" />
            <animateTransform attributeName="gradientTransform" type="translate" from="-2624 0" to="2624 0" dur="7s" repeatCount="indefinite" />
        </linearGradient>
        </defs>
    </svg>;
}
