import React, { useEffect, useState } from 'react';
import { FileCard } from '@instinct/files';
import { YaMark } from './YaMark';
import noiseUrl from './photos/noise.png';

const WHATSAPP = 'https://wa.me/201220906218?text=%D8%A3%D9%87%D9%84%D8%A7%D9%8B+YA%21+%F0%9F%91%8B+%D8%B9%D9%86%D8%AF%D9%8A+%D9%85%D8%B4%D8%B1%D9%88%D8%B9+%D9%88%D8%B9%D8%A7%D9%8A%D8%B2+%D8%A3%D8%B3%D8%AA%D9%81%D8%B3%D8%B1+%D8%B9%D9%86+%D8%AE%D8%AF%D9%85%D8%A7%D8%AA%D9%83%D9%85.';
const EMAIL = 'mailto:adham05042025@gmail.com';

const services = [
    { n: '01', name: 'Shooting', detail: 'Product, event and brand shoots with a cinematic eye.' },
    { n: '02', name: 'Video Editing', detail: 'Reels, promos and YouTube edits with pacing that holds attention.' },
    { n: '03', name: 'Web Development', detail: 'Fast, sharp websites that sell while you sleep.' },
    { n: '04', name: 'AI Video Generation', detail: 'AI-generated video at commercial quality.' },
    { n: '05', name: 'Social Media Design', detail: 'Visual identities and posts that stop the scroll.' },
];

const works = [
    { n: '01', kind: 'Brand Promo', tag: 'Temporary example', tone: 'a', wide: true },
    { n: '02', kind: 'Social Campaign', tag: 'Temporary example', tone: 'b', wide: false },
    { n: '03', kind: 'Product Reel', tag: 'Temporary example', tone: 'c', wide: false },
];

const clients = ['Client 01', 'Client 02', 'Client 03', 'Client 04', 'Client 05'];

function CairoClock() {
    const fmt = new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Cairo', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    const [now, setNow] = useState(() => fmt.format(new Date()));
    useEffect(() => {
        const tick = () => setNow(fmt.format(new Date()));
        const id = setInterval(tick, 1000);
        return () => clearInterval(id);
    }, []);
    return <span className="ya-clock">Egypt&nbsp;&mdash;&nbsp;{now}&nbsp;local</span>;
}

const steps = [
    { n: '1', title: 'We listen', detail: 'You tell us the idea and what it needs to achieve.' },
    { n: '2', title: 'We plan', detail: 'A clear concept and a quote with no surprises.' },
    { n: '3', title: 'We create', detail: 'Production with check-ins at every step.' },
    { n: '4', title: 'We deliver', detail: 'On time, ready to publish.' },
];

function StudioCursor() {
    useEffect(() => {
        if (window.matchMedia('(pointer: coarse)').matches) return;
        const dot = document.querySelector('.ya-cursor-dot');
        const ring = document.querySelector('.ya-cursor-ring');
        if (!dot || !ring) return;
        let x = -100, y = -100, rx = -100, ry = -100, raf = 0;
        const onMove = (e) => { x = e.clientX; y = e.clientY;
            const card = document.querySelector('.ya-card');
            if (card) {
                card.style.setProperty('--mx', ((e.clientX / window.innerWidth) - 0.5).toFixed(3));
                card.style.setProperty('--my', ((e.clientY / window.innerHeight) - 0.5).toFixed(3));
            }
        };
        const onOver = (e) => {
            const t = e.target.closest('a, .ya-client, .ya-service, .ya-work');
            ring.classList.toggle('ya-cursor-active', !!t);
        };
        const loop = () => {
            rx += (x - rx) * 0.16;
            ry += (y - ry) * 0.16;
            dot.style.transform = `translate(${x - 4}px, ${y - 4}px)`;
            ring.style.transform = `translate(${rx - 17}px, ${ry - 17}px)`;
            raf = requestAnimationFrame(loop);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseover', onOver);
        raf = requestAnimationFrame(loop);
        return () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseover', onOver);
            cancelAnimationFrame(raf);
        };
    }, []);
    return <><span className="ya-cursor-dot" aria-hidden="true" /><span className="ya-cursor-ring" aria-hidden="true" /></>;
}

function ScrollFixes() {
    useEffect(() => {
        if (!('IntersectionObserver' in window)) return;
        const bar = document.querySelector('.ya-progressbar');
        const touch = window.matchMedia('(hover: none)').matches;
        const focusEls = touch ? Array.from(document.querySelectorAll('.ya-work, .ya-step, .ya-client')) : [];
        const probes = Array.from(document.querySelectorAll('.ya-hero, .ya-marquee, .ya-section, .ya-contact, .ya-footer'));
        if (!probes.length) return;
        const visible = new Map<Element, DOMRectReadOnly>();
        const apply = () => {
            let top = Infinity; let bottom = -Infinity;
            visible.forEach((r) => { if (r.height > 0) { top = Math.min(top, r.top); bottom = Math.max(bottom, r.bottom); } });
            if (top === Infinity || bottom <= top) return;
            const doc = document.documentElement.scrollHeight || 1;
            if (bar) {
                (bar as HTMLElement).style.top = `${Math.max(0, top)}px`;
                (bar as HTMLElement).style.transform = `scaleX(${Math.max(0.02, Math.min(1, bottom / doc))})`;
            }
            if (!focusEls.length) return;
            const mid = (top + bottom) / 2;
            let best: Element | null = null; let bd = Infinity;
            focusEls.forEach((el) => {
                const r = el.getBoundingClientRect();
                const d = Math.abs(r.top + r.height / 2 - mid);
                if (d < bd) { bd = d; best = el; }
            });
            focusEls.forEach((el) => el.classList.toggle('ya-focus', el === best && bd < (bottom - top) * 0.6));
        };
        const io = new IntersectionObserver((entries) => {
            entries.forEach((en) => {
                if (en.isIntersecting) visible.set(en.target, en.intersectionRect); else visible.delete(en.target);
            });
            apply();
        }, { threshold: [0, 0.5, 1] });
        probes.forEach((p) => io.observe(p));
        focusEls.forEach((el) => io.observe(el));
        return () => io.disconnect();
    }, []);
    return null;
}

export function App() {
    return <FileCard className="ya-card" lang="en" dir="ltr" id="ya-top">
        <span className="ya-progressbar" aria-hidden="true" />
        <span className="ya-vignette" aria-hidden="true" />
        <StudioCursor />
        <ScrollFixes />
        <header className="ya-topbar">
            <span className="ya-topbar-item">YA!&reg; Creative Studio</span>
            <span className="ya-topbar-item"><CairoClock /></span>
        </header>

        <section className="ya-hero">
            <div className="ya-glow" aria-hidden="true">
                <span className="ya-glow-a" /><span className="ya-glow-b" /><span className="ya-glow-c" />
            </div>
            <h1 className="ya-mark-h"><YaMark /></h1>
            <div className="ya-statement-row">
                <p className="ya-statement">
                    {'We turn ideas into content people '.split(' ').filter(Boolean).map((w, i) => <span className="ya-w" style={{ animationDelay: `${1.5 + i * 0.07}s` }} key={w + i}>{w}&nbsp;</span>)}
                    <em>{'actually watch.'.split(' ').map((w, i) => <span className="ya-w" style={{ animationDelay: `${1.85 + i * 0.07}s` }} key={w + i}>{w}{i === 0 ? '\u00a0' : ''}</span>)}</em>
                </p>
                <p className="ya-intro">A creative studio for shooting, video editing, web development, AI&#8209;generated video and social media design. From first idea to final post, everything under one roof.</p>
            </div>
            <div className="ya-links">
                <a className="ya-link ya-link-strong" href={WHATSAPP} target="_blank" rel="noreferrer">Start a project<span className="ya-arrow">↗</span></a>
                <a className="ya-link" href={EMAIL}>adham05042025@gmail.com<span className="ya-arrow">↗</span></a>
                <span className="ya-avail"><span className="ya-avail-dot" />Available for new projects</span>
            </div>
            <span className="ya-scroll-hint" aria-hidden="true"><span className="ya-scroll-line" />Scroll</span>
            <span className="ya-side-cap ya-side-l" aria-hidden="true">Creative Studio</span>
            <span className="ya-side-cap ya-side-r" aria-hidden="true">First Edition &mdash; 2026</span>
        </section>

        <div className="ya-marquee" aria-hidden="true">
            <div className="ya-marquee-track">
                {[0, 1].map((i) => <span className="ya-marquee-run" key={i}>
                    {['Shooting', 'Video Editing', 'Web Development', 'AI Video', 'Social Media Design', 'YA! Creative Studio'].map((t) => <span className="ya-marquee-item" key={t}>{t}<span className="ya-marquee-dot" /></span>)}
                </span>)}
            </div>
        </div>
        <section className="ya-section">
            <div className="ya-section-head">
                <span className="ya-index">01</span>
                <span className="ya-section-label" data-count="(05)">Services</span>
                <span className="ya-wm" aria-hidden="true">Services</span>
            </div>
            <div className="ya-services">
                {services.map((s) => <div className="ya-service" key={s.n}>
                    <span className="ya-service-n">{s.n}</span>
                    <h3 className="ya-service-name">{s.name}</h3>
                    <p className="ya-service-detail">{s.detail}</p>
                </div>)}
            </div>
        </section>

        <section className="ya-section">
            <div className="ya-section-head">
                <span className="ya-index">02</span>
                <span className="ya-section-label" data-count="(03)">Selected Work</span>
                <span className="ya-wm" aria-hidden="true">Work</span>
                <span className="ya-section-note">Temporary examples &mdash; real agency projects land here soon.</span>
            </div>
            <div className="ya-works" style={{ '--ya-noise': `url(${noiseUrl})` } as React.CSSProperties}>
                {works.map((w) => <figure className={`ya-work ya-work-${w.tone} ${w.wide ? 'ya-work-wide' : ''}`} key={w.n} onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`); e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`); }}>
                    <span className="ya-work-sheen" aria-hidden="true" />
                    <span className="ya-work-motif" aria-hidden="true" />
                    <span className="ya-work-n">{w.n}</span>
                    <figcaption className="ya-work-meta">
                        <span className="ya-work-kind">{w.kind}</span>
                        <span className="ya-work-tag">{w.tag}</span>
                    </figcaption>
                </figure>)}
            </div>
        </section>

        <section className="ya-section">
            <div className="ya-section-head">
                <span className="ya-index">03</span>
                <span className="ya-section-label" data-count="(05)">Our Clients</span>
                <span className="ya-wm" aria-hidden="true">Clients</span>
                <span className="ya-section-note">Temporary &mdash; real client logos land here soon.</span>
            </div>
            <div className="ya-clients">
                {clients.map((c) => <span className="ya-client" key={c}>{c}</span>)}
            </div>
        </section>

        <section className="ya-section">
            <div className="ya-section-head">
                <span className="ya-index">04</span>
                <span className="ya-section-label" data-count="(04)">How we work</span>
                <span className="ya-wm" aria-hidden="true">Process</span>
            </div>
            <div className="ya-steps">
                {steps.map((s) => <div className="ya-step" key={s.n}>
                    <span className="ya-step-n">{s.n}</span>
                    <h3 className="ya-step-title">{s.title}</h3>
                    <p className="ya-step-detail">{s.detail}</p>
                </div>)}
            </div>
        </section>

        <div className="ya-marquee ya-marquee-rev" aria-hidden="true">
            <div className="ya-marquee-track">
                {[0, 1].map((i) => <span className="ya-marquee-run" key={i}>
                    {['Shooting', 'Video Editing', 'Web Development', 'AI Video', 'Social Media Design', 'YA! Creative Studio'].map((t) => <span className="ya-marquee-item" key={t}>{t}<span className="ya-marquee-dot" /></span>)}
                </span>)}
            </div>
        </div>
        <section className="ya-contact">
            <span className="ya-wm ya-wm-talk" aria-hidden="true">Talk</span>
            <h2 className="ya-contact-title">Got an<br /><em>idea?</em></h2>
            <p className="ya-contact-text">Tell us about it on WhatsApp or by email &mdash; we reply fast.</p>
            <div className="ya-links">
                <a className="ya-link ya-link-strong" href={WHATSAPP} target="_blank" rel="noreferrer">WhatsApp us<span className="ya-arrow">↗</span></a>
                <a className="ya-link" href={EMAIL}>adham05042025@gmail.com<span className="ya-arrow">↗</span></a>
            </div>
        </section>

        <div className="ya-grain" aria-hidden="true" style={{ backgroundImage: `url(${noiseUrl})` }} />
        <footer className="ya-footer">
            <div className="ya-footer-mark2" aria-hidden="true"><YaMark labelled={false} /></div>
            <div className="ya-footer-bar">
                <span>YA! Agency &mdash; First edition, Nov 2026</span>
                <span>Work shown is temporary</span>
                <a className="ya-totop" href="#ya-top">Back to top<span className="ya-arrow">↑</span></a>
            </div>
        </footer>
    </FileCard>;
}
